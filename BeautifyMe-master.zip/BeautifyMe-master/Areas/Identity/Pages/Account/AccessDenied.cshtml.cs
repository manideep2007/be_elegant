﻿#nullable disable

using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BeautifyMe.Areas.Identity.Pages.Account
{
    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
